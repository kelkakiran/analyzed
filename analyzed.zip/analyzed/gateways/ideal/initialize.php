<?php
  /**
   * iDeal Form
   *
   * @package Membership Manager Pro
   * @author wojoscripts.com
   * @copyright 2016
   * @version $Id: form.tpl.php, v3.00 2016-04-14 10:12:05 gewa Exp $
   */
  if (!defined("_WOJO"))
      die('Direct access to this location is not allowed.');


require_once dirname(__FILE__) . "/Mollie/API/Autoloader.php";